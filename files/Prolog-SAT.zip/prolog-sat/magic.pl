% Reference: https://github.com/EvanOman/Prolog-Magic-Square
% To run in console:
% consult(magic).
% time(nxn(X, Sum)).

numberDomain([1,2,3,4,5,6,7,8,9]).

inRange([]).
inRange([H|T]) :- numberDomain(X), member(H, X), inRange(T).

allDistinct([], _).
allDistinct([H|T], Taken) :- not(member(H, Taken)), allDistinct(T, [H|Taken]).

nxn(X, Sum) :-
  X = [S11, S12, S13,
       S21, S22, S23,
       S31, S32, S33],

  inRange(X),
  allDistinct(X, []),

/* Rows */
  R1 = [S11, S12, S13],
  R2 = [S21, S22, S23],
  R3 = [S31, S32, S33],

  /* Columns */
  C1 = [S11, S21, S31],
  C2 = [S12, S22, S32],
  C3 = [S13, S23, S33],

  /* Diagonals */
  Diag1 = [S11, S22, S33],
  Diag2 = [S13, S22, S31],

  sum_list(R1, Sum1),
  sum_list(R2, Sum2),
  sum_list(R3, Sum3),
  sum_list(C1, Sum4),
  sum_list(C2, Sum5),
  sum_list(C3, Sum6),
  sum_list(Diag1, Sum7),
  sum_list(Diag2, Sum8),

  Sum1 = Sum2,
  Sum2 = Sum3,
  Sum3 = Sum4,
  Sum4 = Sum5,
  Sum5 = Sum6,
  Sum6 = Sum7,
  Sum7 = Sum8,

  Sum = Sum8,
  write(S11), write(' '), write(S12), write(' '), write(S13), nl,
  write(S21), write(' '), write(S22), write(' '), write(S23), nl,
  write(S31), write(' '), write(S32), write(' '), write(S33).

