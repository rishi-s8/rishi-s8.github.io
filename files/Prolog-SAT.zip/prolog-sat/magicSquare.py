#!/usr/bin/env python
# coding: utf-8

# In[1]:


from z3 import *
from time import time
import sys


# Reference: https://github.com/0vercl0k/z3-playground/blob/master/magic_square_z3.py
# 
# Self implemented 'Int' version was slightly slower. Still way better than Prolog. :P

# In[2]:


def solve_magic_square(size):
    """Try to a solution for a size-magic square"""
    def column(matrix, i):
        """Get the column i of matrix"""
        return [matrix[j][i] for j in range(size)]

    def get_diagonals(matrix):
        """Get the diagonals of matrix"""
        return ([matrix[i][i] for i in range(size)], [matrix[i][size - i - 1] for i in range(size)])

    def get_constrained_int(x, y, s):
        """Get an Int and add the constraints associated directly in the solver"""
        # Int() is really really slower!
        x = BitVec('x%dy%d' % (x, y), 32)
        s.add(x > 0, x <= size**2)
        return x

    s = Solver()
    magic = (size * (size**2 + 1)) / 2
    matrix = [[get_constrained_int(y, x, s) for y in range(size)] for x in range(size)]

    # Each value must be different
    s.add(Distinct([matrix[i][j] for j in range(size) for i in range(size)]))

    for i in range(size):
        # Sum of each line, column must be equal to magic
        s.add(Sum(matrix[i]) == magic, Sum(column(matrix, i)) == magic)

    # Sum of each diagonal must be equal to magic
    d1, d2 = get_diagonals(matrix)
    s.add(Sum(d1) == magic, Sum(d2) == magic)

    if s.check() == unsat:
        raise Exception('The problem is not sat')

    m = s.model()
    return [[m[val].as_long() for val in line] for line in matrix], magic

def display_magic_square(s, magic):
    """Display the magic square with the solution"""
    print('Magic value: %d' % magic)
    for i in range(len(s)):
        print(tuple(s[i]))


# In[3]:


n = 3
print('Trying to find a solution for a %d-magic square..' % n)
t1 = time()
s, magic = solve_magic_square(n)
t2 = time()

print('Time taken: ', (t2 - t1))
display_magic_square(s, magic)


# In[4]:


n = 4
print('Trying to find a solution for a %d-magic square..' % n)
t1 = time()
s, magic = solve_magic_square(n)
t2 = time()

print('Time taken: ', (t2 - t1))
display_magic_square(s, magic)


# In[5]:


n = 5
print('Trying to find a solution for a %d-magic square..' % n)
t1 = time()
s, magic = solve_magic_square(n)
t2 = time()

print('Time taken: ', (t2 - t1))
display_magic_square(s, magic)


# In[6]:


n = 6
print('Trying to find a solution for a %d-magic square..' % n)
t1 = time()
s, magic = solve_magic_square(n)
t2 = time()

print('Time taken: ', (t2 - t1))
display_magic_square(s, magic)


# In[ ]:




