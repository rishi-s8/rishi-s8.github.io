#!/usr/bin/env python
# coding: utf-8

# In[9]:


from z3 import *
import sys
from random import randint
from collections import defaultdict
from time import time
get_ipython().run_line_magic('matplotlib', 'inline') # May need to modify this if you don't want to run in a Jupyter Notebook.
import matplotlib.pyplot as plt


# In[10]:


def readGraph():
    g = defaultdict(list)
    file = open("edges.txt", "r")
    edges = file.readlines()
    edges = set(edges)
    n=0
    new_edges = []
    for t in edges:
        x,y = map(int,t.split(','))
        new_edges.append((x,y))
        n = max(n,max(x,y))
        g[x].append(y)
    file.close()
    return g, n+1, new_edges


# In[11]:


g,n,edges = readGraph()
m = len(edges)


# In[12]:


def atLeastOneColor(vs):
    C = True
    for i in vs:
        C = And(C,Or(i))
    return C


# In[13]:


def differentColors(vs, cur_edges, d):
    C = True
    for a,b in cur_edges:
        for l in range(d):
            C=And(C,Or(Not(vs[a][l]), Not(vs[b][l])))
    return C


# In[14]:


def solve(phi):
    s = Solver()
    s.add(phi)
    r = s.check()
    if r == sat:
        m = s.model()
        #print(m)
#         for i in range(n):
#             got_it = False
#             for j in range(d):
#                 if is_true(m[vs[i][j]]):
#                     print("Node: {}, Color: {}".format(i,j))
#                     got_it = True
#             if got_it == False:
#                 print("Node: {}, No Color".format(i))
    else:
        print("unsat")


# In[15]:


def getConstraints(vs, cur_edges, d):
    Constraints = []
    Constraints.append(atLeastOneColor(vs))
    Constraints.append(differentColors(vs, cur_edges, d))
    return And(Constraints)


# **colors -> c01  c02  c03  c04 ...**
# 
# **node1** -> p11  p12  p13  p14 ...
# 
# **node2** -> p21  p22  p23  p24 ...
# 
# **node3** -> p31  p32  p33  p34 ...

# In[16]:


d = 3
timeTaken = []
timeSteps = []
print("d: ", d)
for k in range(1, 3000, 100):
    timeSteps.append(k)
    tic = time()
    vs = [  [Bool("p_{}_{}".format(i,j))  for j in range(d)] for i in range(n)]
    cur_edges = edges[0:k]
    
    solve(getConstraints(vs, cur_edges, d))
    timeTaken.append(time()-tic)
    print("k: {}, time: {}".format(k,round(timeTaken[-1], 3)))


# In[17]:

plt.plot(timeSteps,timeTaken)

