#!/usr/bin/env python
# coding: utf-8

# Try: pip3 install z3-solver
# If the above doesn't work: Find Installation Instructions at https://github.com/Z3Prover/z3

# In[1]:


from z3 import *


# In[2]:


# Solver Function
def solve(phi):
    print("Formula: ", phi)
    s = Solver()
    s.add(phi)
    r = s.check()
    if r == sat:
        m = s.model()
        print("Model: ", m)
    else:
        print("unsat")


# # Example 1
# <img src="circuit.png">

# In[3]:


#Example 1
A = Bool("A")
B = Bool("B")
C = Bool("C")
E = And(A,B)
F = Or(B,C)
G = And(A,C)
H = Not(Or(F,G))
D = Or(E,H)
solve(D)


# In[4]:


# Checking for Real Values
x = Real('x')
y = Real('y')
phi = And(x+y > 5, x>1, y>1)
solve(phi)
# Output is Rational


# # Example 2 : Bounded Model Checking
# 
# ```c++
# int foo(float x, float y) {
#     float z0 = x * y;
#     float z1 = z0 + x;
#     float z2 = z0 * z0 + y;
#     if (y > 0)
#         assert (z2 > 5.0);
#     return z2;
# }
# ```

# In[5]:


# Bounded Model Checking
x = Real('x')
y = Real('y')
z0 = x * y
z1 = z0 + x
z2 = z0 * z0 + y
z = (And(z2<=5.0, y>0))
solve(z)


# In[ ]:




